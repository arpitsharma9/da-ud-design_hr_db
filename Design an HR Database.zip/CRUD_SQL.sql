
--Question 1: Return a list of employees with Job Titles and Department Names

Select  e.Employee_Name , j.Job_Title ,d.Department_Name 
from Employee as e
Join Employee_History as eh
on e.Employee_ID=eh.Employee_ID
Join Job as j
on eh.Job_ID=j.Job_ID
Join Department as d
on eh.Department_ID=d.Department_ID;

--Question 2: Insert Web Programmer as a new job title

Insert Into Job(Job_Title)
Values ('Web Programmer');
Select * from Job;

-- Question 3: Correct the job title from web programmer to web developer

Update Job 
set Job_Title='web developer'
where Job_Title='Web Programmer';
Select * from Job;

-- Question 4: Delete the job title Web Developer from the database

Delete from Job 
where Job_Title='web developer';
Select * from Job;


Question 5: How many employees are in each department?

Select  d.Department_Name , count(e.Employee_Name) as Employee_Count
from Employee as e
Join Employee_History as eh
on e.Employee_ID=eh.Employee_ID
Join Department as d
on eh.Department_ID=d.Department_ID
group by d.Department_Name ;


Question 6: Write a query that returns current and past jobs (include employee name, job title, department, manager name, start and end date for position) for employee Toni Lembeck.

Select e.Employee_Name ,
j.Job_Title ,d.Department_Name ,
(Select Employee_Name from Employee as e where e.Employee_ID=eh.Manager_ID)
as Manager_Name ,eh.Start_date ,eh.End_Date 
from Employee as e
Join Employee_History as eh
on e.Employee_ID=eh.Employee_ID
Join Job as j
on eh.Job_ID=j.Job_ID
Join Department as d
on eh.Department_ID=d.Department_ID
where e.Employee_Name='Toni Lembeck';
